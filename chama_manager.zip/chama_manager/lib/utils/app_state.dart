import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Holds admin/view mode + shared settings (PIN, default rates).
/// Everything here is local-only (SharedPreferences), matching the
/// offline, single-device nature of the app.
class AppState extends ChangeNotifier {
  static const _kPinKey = 'admin_pin';
  static const _kDefaultInterestKey = 'default_interest_rate';
  static const _kDefaultPenaltyKey = 'default_penalty_rate';
  static const _defaultPin = '1234';

  bool _isAdmin = false;
  double _defaultInterestRate = 5.0; // percent per month
  double _defaultPenaltyRate = 2.0; // percent per month overdue

  bool get isAdmin => _isAdmin;
  double get defaultInterestRate => _defaultInterestRate;
  double get defaultPenaltyRate => _defaultPenaltyRate;

  Future<void> loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    _defaultInterestRate = prefs.getDouble(_kDefaultInterestKey) ?? 5.0;
    _defaultPenaltyRate = prefs.getDouble(_kDefaultPenaltyKey) ?? 2.0;
    notifyListeners();
  }

  Future<String> _getPin() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_kPinKey) ?? _defaultPin;
  }

  Future<bool> verifyPin(String candidate) async {
    final storedPin = await _getPin();
    if (candidate == storedPin) {
      _isAdmin = true;
      notifyListeners();
      return true;
    }
    return false;
  }

  Future<void> setPin(String newPin) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kPinKey, newPin);
  }

  void logout() {
    _isAdmin = false;
    notifyListeners();
  }

  Future<void> setDefaultRates({double? interest, double? penalty}) async {
    final prefs = await SharedPreferences.getInstance();
    if (interest != null) {
      _defaultInterestRate = interest;
      await prefs.setDouble(_kDefaultInterestKey, interest);
    }
    if (penalty != null) {
      _defaultPenaltyRate = penalty;
      await prefs.setDouble(_kDefaultPenaltyKey, penalty);
    }
    notifyListeners();
  }
}
