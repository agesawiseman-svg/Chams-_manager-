class Contribution {
  final int? id;
  final int memberId;
  final double amount;
  final String date; // ISO 8601 string
  final String note;

  Contribution({
    this.id,
    required this.memberId,
    required this.amount,
    required this.date,
    this.note = '',
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'member_id': memberId,
      'amount': amount,
      'date': date,
      'note': note,
    };
  }

  factory Contribution.fromMap(Map<String, dynamic> map) {
    return Contribution(
      id: map['id'] as int?,
      memberId: map['member_id'] as int,
      amount: (map['amount'] as num).toDouble(),
      date: map['date'] as String,
      note: map['note'] as String? ?? '',
    );
  }
}
