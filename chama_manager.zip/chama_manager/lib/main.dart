import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'db/db_helper.dart';
import 'utils/app_state.dart';
import 'screens/home_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  DBHelper.initPlatform();
  runApp(const ChamaManagerApp());
}

class ChamaManagerApp extends StatelessWidget {
  const ChamaManagerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => AppState()..loadSettings(),
      child: MaterialApp(
        title: 'Group Contribution Tracker',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
          useMaterial3: true,
        ),
        home: const HomeScreen(),
      ),
    );
  }
}
