import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../utils/app_state.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late TextEditingController _interestCtrl;
  late TextEditingController _penaltyCtrl;
  final _newPinCtrl = TextEditingController();
  final _confirmPinCtrl = TextEditingController();
  String? _pinMessage;

  @override
  void initState() {
    super.initState();
    final appState = context.read<AppState>();
    _interestCtrl =
        TextEditingController(text: appState.defaultInterestRate.toString());
    _penaltyCtrl =
        TextEditingController(text: appState.defaultPenaltyRate.toString());
  }

  Future<void> _saveRates() async {
    final interest = double.tryParse(_interestCtrl.text);
    final penalty = double.tryParse(_penaltyCtrl.text);
    if (interest == null || penalty == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter valid numbers for both rates')),
      );
      return;
    }
    await context.read<AppState>().setDefaultRates(interest: interest, penalty: penalty);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Default rates saved')),
      );
    }
  }

  Future<void> _changePin() async {
    if (_newPinCtrl.text.isEmpty || _newPinCtrl.text != _confirmPinCtrl.text) {
      setState(() => _pinMessage = 'PINs do not match');
      return;
    }
    await context.read<AppState>().setPin(_newPinCtrl.text);
    setState(() {
      _pinMessage = 'PIN updated';
      _newPinCtrl.clear();
      _confirmPinCtrl.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          const Text('Default Loan Rates', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),
          TextField(
            controller: _interestCtrl,
            decoration: const InputDecoration(labelText: 'Default interest rate (% per month)'),
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _penaltyCtrl,
            decoration: const InputDecoration(labelText: 'Default penalty rate (% per month overdue)'),
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
          ),
          const SizedBox(height: 12),
          FilledButton(onPressed: _saveRates, child: const Text('Save Default Rates')),
          const Divider(height: 40),
          const Text('Change Admin PIN', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),
          TextField(
            controller: _newPinCtrl,
            decoration: const InputDecoration(labelText: 'New PIN'),
            obscureText: true,
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _confirmPinCtrl,
            decoration: const InputDecoration(labelText: 'Confirm new PIN'),
            obscureText: true,
            keyboardType: TextInputType.number,
          ),
          if (_pinMessage != null) ...[
            const SizedBox(height: 8),
            Text(_pinMessage!, style: const TextStyle(color: Colors.blueGrey)),
          ],
          const SizedBox(height: 12),
          FilledButton(onPressed: _changePin, child: const Text('Update PIN')),
        ],
      ),
    );
  }
}
