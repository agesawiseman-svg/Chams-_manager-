import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../db/db_helper.dart';
import '../models/member.dart';
import '../models/contribution.dart';
import '../models/loan.dart';
import '../utils/app_state.dart';
import '../utils/loan_calculator.dart';
import 'add_edit_member_screen.dart';
import 'add_contribution_screen.dart';
import 'add_loan_screen.dart';
import 'return_loan_screen.dart';

class MemberDetailScreen extends StatefulWidget {
  final int memberId;
  const MemberDetailScreen({super.key, required this.memberId});

  @override
  State<MemberDetailScreen> createState() => _MemberDetailScreenState();
}

class _MemberDetailScreenState extends State<MemberDetailScreen>
    with SingleTickerProviderStateMixin {
  Member? _member;
  List<Contribution> _contributions = [];
  List<Loan> _loans = [];
  double _totalContributions = 0;
  bool _loading = true;
  final _currency = NumberFormat.currency(symbol: '', decimalDigits: 2);
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _refresh();
  }

  Future<void> _refresh() async {
    setState(() => _loading = true);
    final member = await DBHelper.instance.getMember(widget.memberId);
    final contributions =
        await DBHelper.instance.getContributionsForMember(widget.memberId);
    final loans = await DBHelper.instance.getLoansForMember(widget.memberId);
    final total =
        await DBHelper.instance.totalContributionsForMember(widget.memberId);
    setState(() {
      _member = member;
      _contributions = contributions;
      _loans = loans;
      _totalContributions = total;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    if (_loading || _member == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(_member!.name),
        actions: [
          if (appState.isAdmin)
            IconButton(
              icon: const Icon(Icons.edit),
              onPressed: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => AddEditMemberScreen(existing: _member),
                  ),
                );
                _refresh();
              },
            ),
        ],
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Contributions'),
            Tab(text: 'Loans'),
          ],
        ),
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16.0),
            color: Theme.of(context).colorScheme.surfaceContainerHighest,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Phone: ${_member!.phone}'),
                Text(
                  'Member since: ${DateTime.parse(_member!.joinDate).toLocal().toString().split(' ')[0]}',
                ),
                const SizedBox(height: 8),
                Text(
                  'Total contributions: ${_currency.format(_totalContributions)}',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
              ],
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildContributionsTab(),
                _buildLoansTab(),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: appState.isAdmin
          ? FloatingActionButton.extended(
              onPressed: () async {
                if (_tabController.index == 0) {
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => AddContributionScreen(memberId: widget.memberId),
                    ),
                  );
                } else {
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => AddLoanScreen(memberId: widget.memberId),
                    ),
                  );
                }
                _refresh();
              },
              icon: const Icon(Icons.add),
              label: Text(_tabController.index == 0 ? 'Add Contribution' : 'Add Loan'),
            )
          : null,
    );
  }

  Widget _buildContributionsTab() {
    if (_contributions.isEmpty) {
      return const Center(child: Text('No contributions recorded yet.'));
    }
    return ListView.builder(
      itemCount: _contributions.length,
      itemBuilder: (ctx, i) {
        final c = _contributions[i];
        return ListTile(
          leading: const Icon(Icons.savings),
          title: Text(_currency.format(c.amount)),
          subtitle: Text(
            '${DateTime.parse(c.date).toLocal().toString().split(' ')[0]}'
            '${c.note.isNotEmpty ? ' • ${c.note}' : ''}',
          ),
        );
      },
    );
  }

  Widget _buildLoansTab() {
    final appState = context.watch<AppState>();
    if (_loans.isEmpty) {
      return const Center(child: Text('No loans recorded yet.'));
    }
    return ListView.builder(
      itemCount: _loans.length,
      itemBuilder: (ctx, i) {
        final loan = _loans[i];
        final calc = calculateLoan(loan);
        final isActive = loan.status == 'active';

        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Borrowed: ${_currency.format(loan.principal)}',
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                    Chip(
                      label: Text(isActive ? 'ACTIVE' : 'RETURNED'),
                      backgroundColor: isActive
                          ? (calc.isOverdue ? Colors.red.shade100 : Colors.blue.shade100)
                          : Colors.green.shade100,
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text('Borrow date: ${DateTime.parse(loan.borrowDate).toLocal().toString().split(' ')[0]}'),
                Text('Expected return: ${DateTime.parse(loan.expectedReturnDate).toLocal().toString().split(' ')[0]}'),
                if (loan.actualReturnDate != null)
                  Text('Actual return: ${DateTime.parse(loan.actualReturnDate!).toLocal().toString().split(' ')[0]}'),
                const SizedBox(height: 6),
                Text('Interest so far: ${_currency.format(calc.interestAmount)} (${calc.monthsElapsed} mo @ ${loan.interestRatePerMonth}%)'),
                if (calc.isOverdue)
                  Text(
                    'Penalty: ${_currency.format(calc.penaltyAmount)} (${calc.overdueMonths} mo overdue @ ${loan.penaltyRatePerMonth}%)',
                    style: TextStyle(color: Colors.red.shade700),
                  ),
                const SizedBox(height: 4),
                Text(
                  'Total due: ${_currency.format(calc.totalDue)}',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                if (isActive && appState.isAdmin) ...[
                  const SizedBox(height: 8),
                  Align(
                    alignment: Alignment.centerRight,
                    child: FilledButton.tonal(
                      onPressed: () async {
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ReturnLoanScreen(loan: loan),
                          ),
                        );
                        _refresh();
                      },
                      child: const Text('Mark as Returned'),
                    ),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}
