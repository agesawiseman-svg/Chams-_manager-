# Group Contribution Tracker (ChamaManager)

An offline app for tracking member contributions and loans in a group
savings scheme (chama/SACCO-style group). Runs on **Windows** and
**Android** from one codebase, storing everything locally on the device
(no internet required).

## What it does

- Add and manage **members**
- Record **contributions** per member, with running totals
- Record **loans**: amount borrowed, borrow date, expected return date
- When a loan is marked returned, it automatically calculates:
  - **Interest** — flat rate per month on the principal, for every month
    (or part of a month) the loan was out
  - **Penalty** — an extra flat rate per month for every month the loan
    was returned *after* the expected return date
  - **Total due** = principal + interest + penalty
- **Admin PIN**: officials unlock "Admin mode" to add/edit records.
  Anyone without the PIN sees a read-only "View mode" — safe to hand the
  device to a member to check their own numbers.
- **Settings**: change the default interest/penalty rate and the admin PIN.

Default PIN on first run is **1234** — change it immediately from
Settings once you're in Admin mode.

## How the interest/penalty math works

See `lib/utils/loan_calculator.dart`. In short:

- Any part of a month counts as a full month (standard practice for
  flat-rate group lending), so if a loan is out for 32 days, that's
  charged as 2 months of interest.
- Interest is always charged for the time the loan was outstanding
  (borrow date → return date, or today if still active).
- Penalty is only charged for time *past* the expected return date.
- You can change the interest/penalty rate per loan at the time you
  create it (it starts pre-filled with your default rates from Settings).

## Requirements to build this yourself

You'll need the **Flutter SDK** installed on a Windows PC (Android
builds can also be done from Windows). This is a one-time setup:

1. Install Flutter: https://docs.flutter.dev/get-started/install/windows
2. Install Android Studio (for the Android SDK + emulator):
   https://developer.android.com/studio
3. Run `flutter doctor` in a terminal and follow any instructions it
   gives you until everything has a green checkmark.
4. Enable Windows desktop support (one-time):
   ```
   flutter config --enable-windows-desktop
   ```

## Setting up this project

1. Unzip the project folder you downloaded, e.g. to
   `C:\Users\YourName\chama_manager`.
2. Open a terminal in that folder and run:
   ```
   flutter create --platforms=windows,android .
   ```
   This generates the native `windows/` and `android/` platform folders
   for the app (they aren't included in the download — Flutter
   generates them to match your installed SDK versions).
3. Install dependencies:
   ```
   flutter pub get
   ```

## Running the app

- **On Windows (as a desktop app):**
  ```
  flutter run -d windows
  ```
- **On an Android phone/emulator:**
  Connect your phone via USB with USB debugging enabled (or start an
  Android emulator from Android Studio), then:
  ```
  flutter run -d android
  ```

## Building the final installable files

- **Windows .exe:**
  ```
  flutter build windows
  ```
  The app will be in `build\windows\x64\runner\Release\`. Copy that
  whole folder to share/install it on another Windows PC.

- **Android .apk** (installable file you can send to any Android phone):
  ```
  flutter build apk --release
  ```
  The file will be at `build\app\outputs\flutter-apk\app-release.apk`.

## Project structure

```
lib/
  models/          Member, Contribution, Loan data classes
  db/               SQLite database helper (sqflite + sqflite_common_ffi)
  utils/
    loan_calculator.dart   Interest & penalty math
    app_state.dart         Admin PIN + default rate settings
  screens/          All UI screens
  main.dart         App entry point
```

## Notes & things you may want to customize

- **Backup**: since everything is stored only on one device, back up the
  database file regularly. On Windows it's normally under
  `%APPDATA%\com.example\chama_manager\` — you can add an
  export/import feature later if you want an easy backup button.
- **Multiple devices**: this version is single-device/offline by design
  (as requested). If your group later wants officials on different
  devices to see the same data, that would need a small backend or a
  cloud database — happy to help extend it if that becomes useful.
- **Currency symbol**: amounts are shown as plain numbers. Open
  `lib/screens/member_detail_screen.dart` and
  `lib/screens/return_loan_screen.dart` and change the `NumberFormat`
  lines if you want a currency symbol (e.g. `symbol: 'KSh '`).

## Monthly contributions

- In **Settings**, set the amount each member should pay per month.
- Each payment is tagged with the month it is *for* (default: this month),
  so a late payment can still count toward an earlier month.
- Each member has a **Monthly** tab: every month since they joined, marked
  Paid / Partial / Not paid, plus Expected, Paid and Outstanding totals.
  In Admin mode, tap a month to record a payment for it.
- The calendar icon on the home screen opens the **Monthly Summary**: for
  any month, who has paid and the total collected.
- Payments recorded before this feature are counted in the month they
  were paid.
