class Member {
  final int? id;
  final String name;
  final String phone;
  final String joinDate; // ISO 8601 string

  Member({
    this.id,
    required this.name,
    required this.phone,
    required this.joinDate,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'phone': phone,
      'join_date': joinDate,
    };
  }

  factory Member.fromMap(Map<String, dynamic> map) {
    return Member(
      id: map['id'] as int?,
      name: map['name'] as String,
      phone: map['phone'] as String,
      joinDate: map['join_date'] as String,
    );
  }

  Member copyWith({String? name, String? phone, String? joinDate}) {
    return Member(
      id: id,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      joinDate: joinDate ?? this.joinDate,
    );
  }
}
