class Contribution {
  final int? id;
  final int memberId;
  final double amount;
  final String date; // ISO 8601 string: when the money was paid
  final String note;
  final String? forMonth; // "yyyy-MM": which month this payment counts for

  Contribution({
    this.id,
    required this.memberId,
    required this.amount,
    required this.date,
    this.note = '',
    this.forMonth,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'member_id': memberId,
      'amount': amount,
      'date': date,
      'note': note,
      'for_month': forMonth,
    };
  }

  factory Contribution.fromMap(Map<String, dynamic> map) {
    return Contribution(
      id: map['id'] as int?,
      memberId: map['member_id'] as int,
      amount: (map['amount'] as num).toDouble(),
      date: map['date'] as String,
      note: map['note'] as String? ?? '',
      forMonth: map['for_month'] as String?,
    );
  }
}
