class Loan {
  final int? id;
  final int memberId;
  final double principal;
  final double interestRatePerMonth; // percentage, e.g. 5 = 5% per month
  final double penaltyRatePerMonth; // percentage, e.g. 2 = 2% per month overdue
  final String borrowDate; // ISO 8601 string
  final String expectedReturnDate; // ISO 8601 string
  final String? actualReturnDate; // ISO 8601 string, null if still active
  final String status; // 'active' or 'returned'

  Loan({
    this.id,
    required this.memberId,
    required this.principal,
    required this.interestRatePerMonth,
    required this.penaltyRatePerMonth,
    required this.borrowDate,
    required this.expectedReturnDate,
    this.actualReturnDate,
    this.status = 'active',
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'member_id': memberId,
      'principal': principal,
      'interest_rate': interestRatePerMonth,
      'penalty_rate': penaltyRatePerMonth,
      'borrow_date': borrowDate,
      'expected_return_date': expectedReturnDate,
      'actual_return_date': actualReturnDate,
      'status': status,
    };
  }

  factory Loan.fromMap(Map<String, dynamic> map) {
    return Loan(
      id: map['id'] as int?,
      memberId: map['member_id'] as int,
      principal: (map['principal'] as num).toDouble(),
      interestRatePerMonth: (map['interest_rate'] as num).toDouble(),
      penaltyRatePerMonth: (map['penalty_rate'] as num).toDouble(),
      borrowDate: map['borrow_date'] as String,
      expectedReturnDate: map['expected_return_date'] as String,
      actualReturnDate: map['actual_return_date'] as String?,
      status: map['status'] as String,
    );
  }

  Loan copyWithReturn(String actualReturn) {
    return Loan(
      id: id,
      memberId: memberId,
      principal: principal,
      interestRatePerMonth: interestRatePerMonth,
      penaltyRatePerMonth: penaltyRatePerMonth,
      borrowDate: borrowDate,
      expectedReturnDate: expectedReturnDate,
      actualReturnDate: actualReturn,
      status: 'returned',
    );
  }
}
