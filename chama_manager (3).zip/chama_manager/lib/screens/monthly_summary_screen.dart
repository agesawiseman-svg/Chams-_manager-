import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../db/db_helper.dart';
import '../models/contribution.dart';
import '../models/member.dart';
import '../utils/app_state.dart';
import '../utils/monthly_utils.dart';
import 'member_detail_screen.dart';

class _Row {
  final Member member;
  final MonthStatus status;
  _Row(this.member, this.status);
}

/// Shows, for one chosen month, who has paid and who hasn't.
class MonthlySummaryScreen extends StatefulWidget {
  const MonthlySummaryScreen({super.key});

  @override
  State<MonthlySummaryScreen> createState() => _MonthlySummaryScreenState();
}

class _MonthlySummaryScreenState extends State<MonthlySummaryScreen> {
  DateTime _month = DateTime(DateTime.now().year, DateTime.now().month);
  List<Member> _members = [];
  List<Contribution> _all = [];
  bool _loading = true;
  final _currency = NumberFormat.currency(symbol: '', decimalDigits: 2);

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final members = await DBHelper.instance.getMembers();
    final all = await DBHelper.instance.getAllContributions();
    if (!mounted) return;
    setState(() {
      _members = members;
      _all = all;
      _loading = false;
    });
  }

  void _shift(int delta) {
    setState(() => _month = DateTime(_month.year, _month.month + delta));
  }

  @override
  Widget build(BuildContext context) {
    final monthly = context.watch<AppState>().monthlyContribution;
    final key = monthKeyOf(_month);

    final rows = <_Row>[];
    for (final m in _members) {
      double paid = 0;
      for (final c in _all) {
        if (c.memberId == m.id && contributionMonth(c) == key) paid += c.amount;
      }
      final joined = monthKeyOf(DateTime.parse(m.joinDate)).compareTo(key) <= 0;
      if (!joined && paid == 0) continue; // not a member yet that month
      rows.add(_Row(
        m,
        MonthStatus(month: key, expected: joined ? monthly : 0, paid: paid),
      ));
    }

    double collected = 0, expectedTotal = 0;
    int paidCount = 0;
    for (final r in rows) {
      collected += r.status.paid;
      expectedTotal += r.status.expected;
      if (r.status.state == MonthState.paid) paidCount++;
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Monthly Summary')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.chevron_left),
                      onPressed: () => _shift(-1),
                    ),
                    SizedBox(
                      width: 140,
                      child: Text(
                        monthLabel(key),
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.chevron_right),
                      onPressed: () => _shift(1),
                    ),
                  ],
                ),
                Card(
                  margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Collected: ${_currency.format(collected)}'
                          '${monthly > 0 ? ' of ${_currency.format(expectedTotal)}' : ''}',
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          monthly > 0
                              ? '$paidCount of ${rows.length} members fully paid'
                              : 'Set the monthly amount in Settings to see who is behind.',
                        ),
                      ],
                    ),
                  ),
                ),
                Expanded(
                  child: rows.isEmpty
                      ? const Center(child: Text('No members for this month.'))
                      : ListView.builder(
                          itemCount: rows.length,
                          itemBuilder: (ctx, i) {
                            final r = rows[i];
                            final st = r.status.state;
                            return ListTile(
                              leading: Icon(stateIcon(st), color: stateColor(st)),
                              title: Text(r.member.name),
                              subtitle: Text(
                                r.status.expected > 0
                                    ? '${_currency.format(r.status.paid)} of ${_currency.format(r.status.expected)}'
                                    : _currency.format(r.status.paid),
                              ),
                              trailing: Text(
                                stateLabel(st),
                                style: TextStyle(
                                  color: stateColor(st),
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              onTap: () async {
                                await Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) =>
                                        MemberDetailScreen(memberId: r.member.id!),
                                  ),
                                );
                                _load();
                              },
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}
