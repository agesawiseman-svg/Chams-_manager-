import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../db/db_helper.dart';
import '../models/contribution.dart';
import '../utils/app_state.dart';
import '../utils/monthly_utils.dart';

class AddContributionScreen extends StatefulWidget {
  final int memberId;
  final String? initialMonth; // "yyyy-MM"
  final double? initialAmount;
  const AddContributionScreen({
    super.key,
    required this.memberId,
    this.initialMonth,
    this.initialAmount,
  });

  @override
  State<AddContributionScreen> createState() => _AddContributionScreenState();
}

class _AddContributionScreenState extends State<AddContributionScreen> {
  final _formKey = GlobalKey<FormState>();
  final _amountCtrl = TextEditingController();
  final _noteCtrl = TextEditingController();
  DateTime _date = DateTime.now();
  late String _forMonth;
  late List<String> _monthOptions;

  String _fmt(double v) => v == v.roundToDouble() ? v.toStringAsFixed(0) : v.toString();

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    final options = monthsInRange(
      DateTime(now.year, now.month - 35),
      DateTime(now.year, now.month + 6),
    );
    _forMonth = widget.initialMonth ?? monthKeyOf(now);
    if (!options.contains(_forMonth)) options.add(_forMonth);
    options.sort((a, b) => b.compareTo(a));
    _monthOptions = options;

    final monthly = context.read<AppState>().monthlyContribution;
    final startAmount = widget.initialAmount ?? (monthly > 0 ? monthly : null);
    if (startAmount != null) _amountCtrl.text = _fmt(startAmount);
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked != null) setState(() => _date = picked);
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final contribution = Contribution(
      memberId: widget.memberId,
      amount: double.parse(_amountCtrl.text),
      date: _date.toIso8601String(),
      note: _noteCtrl.text.trim(),
      forMonth: _forMonth,
    );
    await DBHelper.instance.insertContribution(contribution);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Add Contribution')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              DropdownButtonFormField<String>(
                value: _forMonth,
                decoration: const InputDecoration(labelText: 'Contribution for month'),
                items: [
                  for (final m in _monthOptions)
                    DropdownMenuItem(value: m, child: Text(monthLabel(m))),
                ],
                onChanged: (v) {
                  if (v != null) setState(() => _forMonth = v);
                },
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _amountCtrl,
                decoration: const InputDecoration(labelText: 'Amount'),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                validator: (v) {
                  if (v == null || v.isEmpty) return 'Amount is required';
                  if (double.tryParse(v) == null) return 'Enter a valid number';
                  return null;
                },
              ),
              const SizedBox(height: 12),
              ListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Date paid'),
                subtitle: Text('${_date.toLocal()}'.split(' ')[0]),
                trailing: const Icon(Icons.calendar_today),
                onTap: _pickDate,
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _noteCtrl,
                decoration: const InputDecoration(labelText: 'Note (optional)'),
              ),
              const SizedBox(height: 24),
              FilledButton(
                onPressed: _save,
                child: const Text('Save Contribution'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
