import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../utils/app_state.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late TextEditingController _interestCtrl;
  late TextEditingController _penaltyCtrl;
  late TextEditingController _monthlyCtrl;
  final _newPinCtrl = TextEditingController();
  final _confirmPinCtrl = TextEditingController();
  String? _pinMessage;

  @override
  void initState() {
    super.initState();
    final appState = context.read<AppState>();
    _interestCtrl =
        TextEditingController(text: appState.defaultInterestRate.toString());
    _penaltyCtrl =
        TextEditingController(text: appState.defaultPenaltyRate.toString());
    final m = appState.monthlyContribution;
    _monthlyCtrl = TextEditingController(
      text: m <= 0 ? '' : (m == m.roundToDouble() ? m.toStringAsFixed(0) : m.toString()),
    );
  }

  Future<void> _saveMonthly() async {
    final amount = double.tryParse(_monthlyCtrl.text.trim());
    if (amount == null || amount < 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter a valid amount')),
      );
      return;
    }
    await context.read<AppState>().setMonthlyContribution(amount);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Monthly amount saved')),
      );
    }
  }

  Future<void> _saveRates() async {
    final interest = double.tryParse(_interestCtrl.text);
    final penalty = double.tryParse(_penaltyCtrl.text);
    if (interest == null || penalty == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter valid numbers for both rates')),
      );
      return;
    }
    await context.read<AppState>().setDefaultRates(interest: interest, penalty: penalty);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Default rates saved')),
      );
    }
  }

  Future<void> _changePin() async {
    if (_newPinCtrl.text.isEmpty || _newPinCtrl.text != _confirmPinCtrl.text) {
      setState(() => _pinMessage = 'PINs do not match');
      return;
    }
    await context.read<AppState>().setPin(_newPinCtrl.text);
    setState(() {
      _pinMessage = 'PIN updated';
      _newPinCtrl.clear();
      _confirmPinCtrl.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          const Text('Appearance', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 12),
          SegmentedButton<ThemeMode>(
            segments: const [
              ButtonSegment(value: ThemeMode.light, label: Text('Light'), icon: Icon(Icons.light_mode)),
              ButtonSegment(value: ThemeMode.dark, label: Text('Dark'), icon: Icon(Icons.dark_mode)),
              ButtonSegment(value: ThemeMode.system, label: Text('Auto'), icon: Icon(Icons.phone_android)),
            ],
            selected: {appState.themeMode},
            onSelectionChanged: (s) => appState.setThemeMode(s.first),
          ),
          const SizedBox(height: 16),
          const Text('Accent color'),
          const SizedBox(height: 8),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              for (int i = 0; i < AppState.palette.length; i++)
                Tooltip(
                  message: AppState.palette[i].name,
                  child: GestureDetector(
                    onTap: () => appState.setColorIndex(i),
                    child: CircleAvatar(
                      radius: 20,
                      backgroundColor: AppState.palette[i].color,
                      child: appState.colorIndex == i
                          ? const Icon(Icons.check, color: Colors.white)
                          : null,
                    ),
                  ),
                ),
            ],
          ),
          const Divider(height: 40),
          const Text('Monthly Contribution', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),
          TextField(
            controller: _monthlyCtrl,
            decoration: const InputDecoration(labelText: 'Amount each member pays per month'),
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
          ),
          const SizedBox(height: 12),
          FilledButton(onPressed: _saveMonthly, child: const Text('Save Monthly Amount')),
          const Divider(height: 40),
          const Text('Default Loan Rates', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),
          TextField(
            controller: _interestCtrl,
            decoration: const InputDecoration(labelText: 'Default interest rate (% per month)'),
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _penaltyCtrl,
            decoration: const InputDecoration(labelText: 'Default penalty rate (% per month overdue)'),
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
          ),
          const SizedBox(height: 12),
          FilledButton(onPressed: _saveRates, child: const Text('Save Default Rates')),
          const Divider(height: 40),
          const Text('Change Admin PIN', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          const SizedBox(height: 8),
          TextField(
            controller: _newPinCtrl,
            decoration: const InputDecoration(labelText: 'New PIN'),
            obscureText: true,
            keyboardType: TextInputType.number,
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _confirmPinCtrl,
            decoration: const InputDecoration(labelText: 'Confirm new PIN'),
            obscureText: true,
            keyboardType: TextInputType.number,
          ),
          if (_pinMessage != null) ...[
            const SizedBox(height: 8),
            Text(_pinMessage!, style: const TextStyle(color: Colors.blueGrey)),
          ],
          const SizedBox(height: 12),
          FilledButton(onPressed: _changePin, child: const Text('Update PIN')),
        ],
      ),
    );
  }
}
