import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../db/db_helper.dart';
import '../models/member.dart';
import '../utils/app_state.dart';
import 'pin_screen.dart';
import 'add_edit_member_screen.dart';
import 'member_detail_screen.dart';
import 'settings_screen.dart';
import 'monthly_summary_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Member> _members = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    setState(() => _loading = true);
    final members = await DBHelper.instance.getMembers();
    setState(() {
      _members = members;
      _loading = false;
    });
  }

  Future<void> _toggleAdmin() async {
    final appState = context.read<AppState>();
    if (appState.isAdmin) {
      appState.logout();
    } else {
      await showPinDialog(context);
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Group Contribution Tracker'),
        actions: [
          IconButton(
            icon: const Icon(Icons.calendar_month),
            tooltip: 'Monthly summary',
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const MonthlySummaryScreen()),
              );
            },
          ),
          if (appState.isAdmin)
            IconButton(
              icon: const Icon(Icons.settings),
              tooltip: 'Settings',
              onPressed: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const SettingsScreen()),
                );
              },
            ),
          TextButton.icon(
            onPressed: _toggleAdmin,
            icon: Icon(
              appState.isAdmin ? Icons.lock_open : Icons.lock,
            ),
            label: Text(
              appState.isAdmin ? 'Admin mode' : 'View mode',
            ),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _members.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24.0),
                    child: Text(
                      'No members yet.\nSwitch to Admin mode and tap + to add one.',
                      textAlign: TextAlign.center,
                    ),
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _refresh,
                  child: ListView.builder(
                    itemCount: _members.length,
                    itemBuilder: (ctx, i) {
                      final m = _members[i];
                      return ListTile(
                        leading: CircleAvatar(
                          child: Text(m.name.isNotEmpty ? m.name[0].toUpperCase() : '?'),
                        ),
                        title: Text(m.name),
                        subtitle: Text(m.phone),
                        trailing: const Icon(Icons.chevron_right),
                        onTap: () async {
                          await Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => MemberDetailScreen(memberId: m.id!),
                            ),
                          );
                          _refresh();
                        },
                      );
                    },
                  ),
                ),
      floatingActionButton: appState.isAdmin
          ? FloatingActionButton(
              onPressed: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AddEditMemberScreen()),
                );
                _refresh();
              },
              child: const Icon(Icons.person_add),
            )
          : null,
    );
  }
}
