import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../db/db_helper.dart';
import '../models/loan.dart';
import '../utils/app_state.dart';

class AddLoanScreen extends StatefulWidget {
  final int memberId;
  const AddLoanScreen({super.key, required this.memberId});

  @override
  State<AddLoanScreen> createState() => _AddLoanScreenState();
}

class _AddLoanScreenState extends State<AddLoanScreen> {
  final _formKey = GlobalKey<FormState>();
  final _principalCtrl = TextEditingController();
  late TextEditingController _interestCtrl;
  late TextEditingController _penaltyCtrl;
  DateTime _borrowDate = DateTime.now();
  DateTime _expectedReturnDate = DateTime.now().add(const Duration(days: 30));

  @override
  void initState() {
    super.initState();
    final appState = context.read<AppState>();
    _interestCtrl =
        TextEditingController(text: appState.defaultInterestRate.toString());
    _penaltyCtrl =
        TextEditingController(text: appState.defaultPenaltyRate.toString());
  }

  Future<void> _pickBorrowDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _borrowDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked != null) {
      setState(() {
        _borrowDate = picked;
        if (_expectedReturnDate.isBefore(_borrowDate)) {
          _expectedReturnDate = _borrowDate.add(const Duration(days: 30));
        }
      });
    }
  }

  Future<void> _pickExpectedReturnDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _expectedReturnDate,
      firstDate: _borrowDate,
      lastDate: DateTime(2100),
    );
    if (picked != null) setState(() => _expectedReturnDate = picked);
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    final loan = Loan(
      memberId: widget.memberId,
      principal: double.parse(_principalCtrl.text),
      interestRatePerMonth: double.parse(_interestCtrl.text),
      penaltyRatePerMonth: double.parse(_penaltyCtrl.text),
      borrowDate: _borrowDate.toIso8601String(),
      expectedReturnDate: _expectedReturnDate.toIso8601String(),
      status: 'active',
    );
    await DBHelper.instance.insertLoan(loan);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('New Loan')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _principalCtrl,
                decoration: const InputDecoration(labelText: 'Amount borrowed'),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                validator: (v) {
                  if (v == null || v.isEmpty) return 'Amount is required';
                  if (double.tryParse(v) == null) return 'Enter a valid number';
                  return null;
                },
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _interestCtrl,
                decoration: const InputDecoration(
                  labelText: 'Interest rate (% per month)',
                ),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                validator: (v) {
                  if (v == null || v.isEmpty) return 'Interest rate is required';
                  if (double.tryParse(v) == null) return 'Enter a valid number';
                  return null;
                },
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _penaltyCtrl,
                decoration: const InputDecoration(
                  labelText: 'Penalty rate (% per month overdue)',
                ),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                validator: (v) {
                  if (v == null || v.isEmpty) return 'Penalty rate is required';
                  if (double.tryParse(v) == null) return 'Enter a valid number';
                  return null;
                },
              ),
              const SizedBox(height: 12),
              ListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Borrow date'),
                subtitle: Text('${_borrowDate.toLocal()}'.split(' ')[0]),
                trailing: const Icon(Icons.calendar_today),
                onTap: _pickBorrowDate,
              ),
              ListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Expected return date'),
                subtitle: Text('${_expectedReturnDate.toLocal()}'.split(' ')[0]),
                trailing: const Icon(Icons.calendar_today),
                onTap: _pickExpectedReturnDate,
              ),
              const SizedBox(height: 24),
              FilledButton(
                onPressed: _save,
                child: const Text('Record Loan'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
