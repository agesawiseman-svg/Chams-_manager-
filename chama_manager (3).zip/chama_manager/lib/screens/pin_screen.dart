import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../utils/app_state.dart';

/// Shows a PIN entry dialog. Returns true if the PIN was correct.
Future<bool> showPinDialog(BuildContext context) async {
  final controller = TextEditingController();
  String? errorText;

  final result = await showDialog<bool>(
    context: context,
    builder: (ctx) {
      return StatefulBuilder(
        builder: (ctx, setState) {
          return AlertDialog(
            title: const Text('Enter Admin PIN'),
            content: TextField(
              controller: controller,
              autofocus: true,
              obscureText: true,
              keyboardType: TextInputType.number,
              maxLength: 8,
              decoration: InputDecoration(
                labelText: 'PIN',
                errorText: errorText,
              ),
              onSubmitted: (_) async {
                final ok = await ctx.read<AppState>().verifyPin(controller.text);
                if (ok) {
                  Navigator.of(ctx).pop(true);
                } else {
                  setState(() => errorText = 'Incorrect PIN');
                }
              },
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(ctx).pop(false),
                child: const Text('Cancel'),
              ),
              FilledButton(
                onPressed: () async {
                  final ok = await ctx.read<AppState>().verifyPin(controller.text);
                  if (ok) {
                    Navigator.of(ctx).pop(true);
                  } else {
                    setState(() => errorText = 'Incorrect PIN');
                  }
                },
                child: const Text('Unlock'),
              ),
            ],
          );
        },
      );
    },
  );

  return result ?? false;
}
