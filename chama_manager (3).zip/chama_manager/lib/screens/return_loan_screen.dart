import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../db/db_helper.dart';
import '../models/loan.dart';
import '../utils/loan_calculator.dart';

class ReturnLoanScreen extends StatefulWidget {
  final Loan loan;
  const ReturnLoanScreen({super.key, required this.loan});

  @override
  State<ReturnLoanScreen> createState() => _ReturnLoanScreenState();
}

class _ReturnLoanScreenState extends State<ReturnLoanScreen> {
  DateTime _returnDate = DateTime.now();
  final _currency = NumberFormat.currency(symbol: '', decimalDigits: 2);

  Future<void> _pickReturnDate() async {
    final borrow = DateTime.parse(widget.loan.borrowDate);
    final picked = await showDatePicker(
      context: context,
      initialDate: _returnDate.isBefore(borrow) ? borrow : _returnDate,
      firstDate: borrow,
      lastDate: DateTime(2100),
    );
    if (picked != null) setState(() => _returnDate = picked);
  }

  Future<void> _confirmReturn() async {
    final updated = widget.loan.copyWithReturn(_returnDate.toIso8601String());
    await DBHelper.instance.updateLoan(updated);
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    // Build a temp loan with the chosen return date so the preview
    // reflects what will actually be saved.
    final previewLoan = Loan(
      id: widget.loan.id,
      memberId: widget.loan.memberId,
      principal: widget.loan.principal,
      interestRatePerMonth: widget.loan.interestRatePerMonth,
      penaltyRatePerMonth: widget.loan.penaltyRatePerMonth,
      borrowDate: widget.loan.borrowDate,
      expectedReturnDate: widget.loan.expectedReturnDate,
      actualReturnDate: _returnDate.toIso8601String(),
      status: 'returned',
    );
    final calc = calculateLoan(previewLoan);

    return Scaffold(
      appBar: AppBar(title: const Text('Return Loan')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Borrow date'),
              subtitle: Text('${DateTime.parse(widget.loan.borrowDate).toLocal()}'.split(' ')[0]),
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Expected return date'),
              subtitle: Text('${DateTime.parse(widget.loan.expectedReturnDate).toLocal()}'.split(' ')[0]),
            ),
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Actual return date'),
              subtitle: Text('${_returnDate.toLocal()}'.split(' ')[0]),
              trailing: const Icon(Icons.calendar_today),
              onTap: _pickReturnDate,
            ),
            const Divider(height: 32),
            _summaryRow('Principal', _currency.format(widget.loan.principal)),
            _summaryRow(
              'Months charged (interest)',
              '${calc.monthsElapsed}',
            ),
            _summaryRow(
              'Interest (${widget.loan.interestRatePerMonth}%/mo)',
              _currency.format(calc.interestAmount),
            ),
            if (calc.isOverdue) ...[
              _summaryRow(
                'Overdue months (penalty)',
                '${calc.overdueMonths}',
                color: Colors.orange.shade800,
              ),
              _summaryRow(
                'Penalty (${widget.loan.penaltyRatePerMonth}%/mo overdue)',
                _currency.format(calc.penaltyAmount),
                color: Colors.orange.shade800,
              ),
            ] else
              _summaryRow('Penalty', 'None — returned on time', color: Colors.green.shade700),
            const Divider(height: 32),
            _summaryRow(
              'Total amount due',
              _currency.format(calc.totalDue),
              bold: true,
            ),
            const SizedBox(height: 24),
            FilledButton(
              onPressed: _confirmReturn,
              child: const Text('Confirm Return'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _summaryRow(String label, String value, {bool bold = false, Color? color}) {
    final style = TextStyle(
      fontWeight: bold ? FontWeight.bold : FontWeight.normal,
      fontSize: bold ? 18 : 14,
      color: color,
    );
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: style),
          Text(value, style: style),
        ],
      ),
    );
  }
}
