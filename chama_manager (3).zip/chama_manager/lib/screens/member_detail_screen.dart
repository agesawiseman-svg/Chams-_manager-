import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../db/db_helper.dart';
import '../models/member.dart';
import '../models/contribution.dart';
import '../models/loan.dart';
import '../utils/app_state.dart';
import '../utils/loan_calculator.dart';
import '../utils/monthly_utils.dart';
import 'add_edit_member_screen.dart';
import 'add_contribution_screen.dart';
import 'add_loan_screen.dart';
import 'return_loan_screen.dart';

class MemberDetailScreen extends StatefulWidget {
  final int memberId;
  const MemberDetailScreen({super.key, required this.memberId});

  @override
  State<MemberDetailScreen> createState() => _MemberDetailScreenState();
}

class _MemberDetailScreenState extends State<MemberDetailScreen>
    with SingleTickerProviderStateMixin {
  Member? _member;
  List<Contribution> _contributions = [];
  List<Loan> _loans = [];
  double _totalContributions = 0;
  bool _loading = true;
  final _currency = NumberFormat.currency(symbol: '', decimalDigits: 2);
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _tabController.addListener(() {
      if (mounted) setState(() {}); // keeps the add-button label in sync
    });
    _refresh();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _refresh() async {
    setState(() => _loading = true);
    final member = await DBHelper.instance.getMember(widget.memberId);
    final contributions =
        await DBHelper.instance.getContributionsForMember(widget.memberId);
    final loans = await DBHelper.instance.getLoansForMember(widget.memberId);
    final total =
        await DBHelper.instance.totalContributionsForMember(widget.memberId);
    if (!mounted) return;
    setState(() {
      _member = member;
      _contributions = contributions;
      _loans = loans;
      _totalContributions = total;
      _loading = false;
    });
  }

  String _dateOnly(String iso) => DateTime.parse(iso).toLocal().toString().split(' ')[0];

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();
    if (_loading || _member == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(_member!.name),
        actions: [
          if (appState.isAdmin)
            IconButton(
              icon: const Icon(Icons.edit),
              onPressed: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => AddEditMemberScreen(existing: _member),
                  ),
                );
                _refresh();
              },
            ),
        ],
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Monthly'),
            Tab(text: 'Payments'),
            Tab(text: 'Loans'),
          ],
        ),
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16.0),
            color: Theme.of(context).colorScheme.surfaceContainerHighest,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Phone: ${_member!.phone}'),
                Text('Member since: ${_dateOnly(_member!.joinDate)}'),
                const SizedBox(height: 8),
                Text(
                  'Total contributions: ${_currency.format(_totalContributions)}',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
              ],
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildMonthlyTab(),
                _buildContributionsTab(),
                _buildLoansTab(),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: appState.isAdmin
          ? FloatingActionButton.extended(
              onPressed: () async {
                if (_tabController.index == 2) {
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => AddLoanScreen(memberId: widget.memberId),
                    ),
                  );
                } else {
                  await Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => AddContributionScreen(memberId: widget.memberId),
                    ),
                  );
                }
                _refresh();
              },
              icon: const Icon(Icons.add),
              label: Text(_tabController.index == 2 ? 'Add Loan' : 'Add Contribution'),
            )
          : null,
    );
  }

  Widget _statTile(String label, String value, {Color? color}) {
    return Expanded(
      child: Column(
        children: [
          Text(label, style: const TextStyle(fontSize: 12)),
          const SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: color),
          ),
        ],
      ),
    );
  }

  Widget _buildMonthlyTab() {
    final appState = context.watch<AppState>();
    final monthly = appState.monthlyContribution;
    final months = buildMemberMonths(
      joinDate: DateTime.parse(_member!.joinDate),
      contributions: _contributions,
      monthlyAmount: monthly,
    );

    double expectedTotal = 0, paidTotal = 0, outstanding = 0;
    for (final m in months) {
      expectedTotal += m.expected;
      paidTotal += m.paid;
      outstanding += m.shortfall;
    }

    return Column(
      children: [
        if (monthly <= 0)
          Card(
            margin: const EdgeInsets.all(12),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Text(
                appState.isAdmin
                    ? 'Set the monthly contribution amount in Settings to see what is owed each month.'
                    : 'The monthly contribution amount has not been set yet.',
              ),
            ),
          ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
          child: Row(
            children: [
              _statTile('Expected', _currency.format(expectedTotal)),
              _statTile('Paid', _currency.format(paidTotal), color: Colors.green.shade600),
              _statTile(
                'Outstanding',
                _currency.format(outstanding),
                color: outstanding > 0 ? Colors.red.shade600 : null,
              ),
            ],
          ),
        ),
        const Divider(height: 1),
        Expanded(
          child: months.isEmpty
              ? const Center(child: Text('No months to show yet.'))
              : ListView.builder(
                  itemCount: months.length,
                  itemBuilder: (ctx, i) {
                    final m = months[i];
                    final st = m.state;
                    return ListTile(
                      leading: Icon(stateIcon(st), color: stateColor(st)),
                      title: Text(monthLabel(m.month)),
                      subtitle: Text(
                        m.expected > 0
                            ? 'Paid ${_currency.format(m.paid)} of ${_currency.format(m.expected)}'
                            : 'Paid ${_currency.format(m.paid)}',
                      ),
                      trailing: Text(
                        stateLabel(st),
                        style: TextStyle(color: stateColor(st), fontWeight: FontWeight.bold),
                      ),
                      onTap: appState.isAdmin
                          ? () async {
                              await Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => AddContributionScreen(
                                    memberId: widget.memberId,
                                    initialMonth: m.month,
                                    initialAmount: m.shortfall > 0 ? m.shortfall : null,
                                  ),
                                ),
                              );
                              _refresh();
                            }
                          : null,
                    );
                  },
                ),
        ),
      ],
    );
  }

  Widget _buildContributionsTab() {
    if (_contributions.isEmpty) {
      return const Center(child: Text('No contributions recorded yet.'));
    }
    return ListView.builder(
      itemCount: _contributions.length,
      itemBuilder: (ctx, i) {
        final c = _contributions[i];
        return ListTile(
          leading: const Icon(Icons.savings),
          title: Text(_currency.format(c.amount)),
          subtitle: Text(
            'For ${monthLabel(contributionMonth(c))} • paid ${_dateOnly(c.date)}'
            '${c.note.isNotEmpty ? ' • ${c.note}' : ''}',
          ),
        );
      },
    );
  }

  Widget _buildLoansTab() {
    final appState = context.watch<AppState>();
    if (_loans.isEmpty) {
      return const Center(child: Text('No loans recorded yet.'));
    }
    return ListView.builder(
      itemCount: _loans.length,
      itemBuilder: (ctx, i) {
        final loan = _loans[i];
        final calc = calculateLoan(loan);
        final isActive = loan.status == 'active';

        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Borrowed: ${_currency.format(loan.principal)}',
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                    Chip(
                      label: Text(isActive ? 'ACTIVE' : 'RETURNED'),
                      backgroundColor: isActive
                          ? (calc.isOverdue ? Colors.red.shade100 : Colors.blue.shade100)
                          : Colors.green.shade100,
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text('Borrow date: ${_dateOnly(loan.borrowDate)}'),
                Text('Expected return: ${_dateOnly(loan.expectedReturnDate)}'),
                if (loan.actualReturnDate != null)
                  Text('Actual return: ${_dateOnly(loan.actualReturnDate!)}'),
                const SizedBox(height: 6),
                Text('Interest so far: ${_currency.format(calc.interestAmount)} (${calc.monthsElapsed} mo @ ${loan.interestRatePerMonth}%)'),
                if (calc.isOverdue)
                  Text(
                    'Penalty: ${_currency.format(calc.penaltyAmount)} (${calc.overdueMonths} mo overdue @ ${loan.penaltyRatePerMonth}%)',
                    style: TextStyle(color: Colors.red.shade700),
                  ),
                const SizedBox(height: 4),
                Text(
                  'Total due: ${_currency.format(calc.totalDue)}',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                if (isActive && appState.isAdmin) ...[
                  const SizedBox(height: 8),
                  Align(
                    alignment: Alignment.centerRight,
                    child: FilledButton.tonal(
                      onPressed: () async {
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ReturnLoanScreen(loan: loan),
                          ),
                        );
                        _refresh();
                      },
                      child: const Text('Mark as Returned'),
                    ),
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}
