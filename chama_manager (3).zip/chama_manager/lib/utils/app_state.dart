import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppThemeColor {
  final String name;
  final Color color;
  const AppThemeColor(this.name, this.color);
}

/// Holds admin/view mode + shared settings (PIN, default rates, theme).
/// Everything here is local-only (SharedPreferences), matching the
/// offline, single-device nature of the app.
class AppState extends ChangeNotifier {
  static const _kPinKey = 'admin_pin';
  static const _kDefaultInterestKey = 'default_interest_rate';
  static const _kDefaultPenaltyKey = 'default_penalty_rate';
  static const _kThemeModeKey = 'theme_mode';
  static const _kThemeColorKey = 'theme_color_index';
  static const _kMonthlyKey = 'monthly_contribution';
  static const _defaultPin = '1234';

  static const List<AppThemeColor> palette = [
    AppThemeColor('Teal', Colors.teal),
    AppThemeColor('Blue', Colors.blue),
    AppThemeColor('Green', Colors.green),
    AppThemeColor('Purple', Colors.deepPurple),
    AppThemeColor('Orange', Colors.deepOrange),
    AppThemeColor('Pink', Colors.pink),
    AppThemeColor('Brown', Colors.brown),
  ];

  bool _isAdmin = false;
  double _defaultInterestRate = 5.0; // percent per month
  double _defaultPenaltyRate = 2.0; // percent per month overdue
  ThemeMode _themeMode = ThemeMode.system;
  int _colorIndex = 0;
  double _monthlyContribution = 0; // 0 = not set yet

  bool get isAdmin => _isAdmin;
  double get defaultInterestRate => _defaultInterestRate;
  double get defaultPenaltyRate => _defaultPenaltyRate;
  ThemeMode get themeMode => _themeMode;
  int get colorIndex => _colorIndex;
  Color get seedColor => palette[_colorIndex].color;
  double get monthlyContribution => _monthlyContribution;

  Future<void> loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    _defaultInterestRate = prefs.getDouble(_kDefaultInterestKey) ?? 5.0;
    _defaultPenaltyRate = prefs.getDouble(_kDefaultPenaltyKey) ?? 2.0;
    _monthlyContribution = prefs.getDouble(_kMonthlyKey) ?? 0;

    switch (prefs.getString(_kThemeModeKey)) {
      case 'light':
        _themeMode = ThemeMode.light;
        break;
      case 'dark':
        _themeMode = ThemeMode.dark;
        break;
      default:
        _themeMode = ThemeMode.system;
    }
    final idx = prefs.getInt(_kThemeColorKey) ?? 0;
    _colorIndex = (idx >= 0 && idx < palette.length) ? idx : 0;
    notifyListeners();
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    _themeMode = mode;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kThemeModeKey, mode.name);
  }

  Future<void> setColorIndex(int index) async {
    if (index < 0 || index >= palette.length) return;
    _colorIndex = index;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kThemeColorKey, index);
  }

  Future<void> setMonthlyContribution(double amount) async {
    _monthlyContribution = amount;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_kMonthlyKey, amount);
  }

  Future<String> _getPin() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_kPinKey) ?? _defaultPin;
  }

  Future<bool> verifyPin(String candidate) async {
    final storedPin = await _getPin();
    if (candidate == storedPin) {
      _isAdmin = true;
      notifyListeners();
      return true;
    }
    return false;
  }

  Future<void> setPin(String newPin) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kPinKey, newPin);
  }

  void logout() {
    _isAdmin = false;
    notifyListeners();
  }

  Future<void> setDefaultRates({double? interest, double? penalty}) async {
    final prefs = await SharedPreferences.getInstance();
    if (interest != null) {
      _defaultInterestRate = interest;
      await prefs.setDouble(_kDefaultInterestKey, interest);
    }
    if (penalty != null) {
      _defaultPenaltyRate = penalty;
      await prefs.setDouble(_kDefaultPenaltyKey, penalty);
    }
    notifyListeners();
  }
}
