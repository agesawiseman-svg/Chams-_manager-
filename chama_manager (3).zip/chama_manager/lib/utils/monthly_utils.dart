import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/contribution.dart';

/// Month keys look like "2026-09" so they sort correctly as text.
String monthKeyOf(DateTime d) =>
    '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}';

DateTime monthFromKey(String key) {
  final parts = key.split('-');
  return DateTime(int.parse(parts[0]), int.parse(parts[1]));
}

String monthLabel(String key) => DateFormat('MMM yyyy').format(monthFromKey(key));

/// The month a contribution counts for. Older records saved before this
/// feature existed have no month, so we use the date they were paid.
String contributionMonth(Contribution c) {
  if (c.forMonth != null && c.forMonth!.length >= 7) return c.forMonth!;
  return c.date.substring(0, 7);
}

List<String> monthsInRange(DateTime start, DateTime end) {
  final months = <String>[];
  var cursor = DateTime(start.year, start.month);
  final last = DateTime(end.year, end.month);
  while (!cursor.isAfter(last)) {
    months.add(monthKeyOf(cursor));
    cursor = DateTime(cursor.year, cursor.month + 1);
  }
  return months;
}

enum MonthState { paid, partial, missing, noTarget }

class MonthStatus {
  final String month;
  final double expected;
  final double paid;

  MonthStatus({required this.month, required this.expected, required this.paid});

  double get shortfall => expected > paid ? expected - paid : 0;

  MonthState get state {
    if (expected <= 0) return paid > 0 ? MonthState.paid : MonthState.noTarget;
    if (paid >= expected) return MonthState.paid;
    if (paid > 0) return MonthState.partial;
    return MonthState.missing;
  }
}

/// Builds the month-by-month history for one member, newest first.
/// Months from the member's join month up to this month are expected to be
/// paid. Any other month that has money in it (e.g. paid in advance) is
/// also listed.
List<MonthStatus> buildMemberMonths({
  required DateTime joinDate,
  required List<Contribution> contributions,
  required double monthlyAmount,
  DateTime? now,
}) {
  final today = now ?? DateTime.now();
  final range = monthsInRange(DateTime(joinDate.year, joinDate.month), today);
  final rangeSet = range.toSet();

  final paidByMonth = <String, double>{};
  for (final c in contributions) {
    final k = contributionMonth(c);
    paidByMonth[k] = (paidByMonth[k] ?? 0) + c.amount;
  }

  final allMonths = <String>{...range, ...paidByMonth.keys}.toList()
    ..sort((a, b) => b.compareTo(a));

  return allMonths
      .map((m) => MonthStatus(
            month: m,
            expected: rangeSet.contains(m) ? monthlyAmount : 0,
            paid: paidByMonth[m] ?? 0,
          ))
      .toList();
}

Color stateColor(MonthState s) {
  switch (s) {
    case MonthState.paid:
      return Colors.green.shade600;
    case MonthState.partial:
      return Colors.orange.shade700;
    case MonthState.missing:
      return Colors.red.shade600;
    case MonthState.noTarget:
      return Colors.grey;
  }
}

IconData stateIcon(MonthState s) {
  switch (s) {
    case MonthState.paid:
      return Icons.check_circle;
    case MonthState.partial:
      return Icons.timelapse;
    case MonthState.missing:
      return Icons.cancel;
    case MonthState.noTarget:
      return Icons.remove_circle_outline;
  }
}

String stateLabel(MonthState s) {
  switch (s) {
    case MonthState.paid:
      return 'Paid';
    case MonthState.partial:
      return 'Partial';
    case MonthState.missing:
      return 'Not paid';
    case MonthState.noTarget:
      return '-';
  }
}
