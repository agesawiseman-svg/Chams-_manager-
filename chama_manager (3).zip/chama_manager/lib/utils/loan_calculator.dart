import '../models/loan.dart';

/// Result of running interest/penalty math on a loan.
class LoanCalculation {
  final int monthsElapsed; // months used to charge interest (borrow -> end date)
  final double interestAmount;
  final int overdueMonths; // months used to charge penalty (expected -> end date)
  final double penaltyAmount;
  final double totalDue; // principal + interest + penalty
  final bool isOverdue;
  final DateTime endDate; // actual return date, or "today" if still active

  LoanCalculation({
    required this.monthsElapsed,
    required this.interestAmount,
    required this.overdueMonths,
    required this.penaltyAmount,
    required this.totalDue,
    required this.isOverdue,
    required this.endDate,
  });
}

/// Counts months between [start] and [end], treating any partial month
/// as a full month (common convention for flat-rate group lending).
/// Returns 0 if end is not after start.
int monthsElapsedBetween(DateTime start, DateTime end) {
  if (!end.isAfter(start)) return 0;
  int months = (end.year - start.year) * 12 + (end.month - start.month);
  if (end.day >= start.day) {
    months += 1;
  } else if (months == 0) {
    months = 1;
  }
  return months < 1 ? 1 : months;
}

/// Calculates interest and penalty for a loan.
/// If the loan has an [actualReturnDate], that is used as the end date.
/// Otherwise "today" (via [now]) is used, so an active overdue loan shows
/// its running total.
LoanCalculation calculateLoan(Loan loan, {DateTime? now}) {
  final DateTime borrowDate = DateTime.parse(loan.borrowDate);
  final DateTime expectedReturn = DateTime.parse(loan.expectedReturnDate);
  final DateTime endDate = loan.actualReturnDate != null
      ? DateTime.parse(loan.actualReturnDate!)
      : (now ?? DateTime.now());

  final int months = monthsElapsedBetween(borrowDate, endDate);
  final double interest =
      loan.principal * (loan.interestRatePerMonth / 100) * months;

  final bool overdue = endDate.isAfter(expectedReturn);
  int overdueMonths = 0;
  double penalty = 0;
  if (overdue) {
    overdueMonths = monthsElapsedBetween(expectedReturn, endDate);
    penalty = loan.principal * (loan.penaltyRatePerMonth / 100) * overdueMonths;
  }

  final double totalDue = loan.principal + interest + penalty;

  return LoanCalculation(
    monthsElapsed: months,
    interestAmount: interest,
    overdueMonths: overdueMonths,
    penaltyAmount: penalty,
    totalDue: totalDue,
    isOverdue: overdue,
    endDate: endDate,
  );
}
