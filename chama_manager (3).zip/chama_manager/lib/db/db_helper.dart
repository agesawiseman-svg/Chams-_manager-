import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import '../models/member.dart';
import '../models/contribution.dart';
import '../models/loan.dart';

class DBHelper {
  DBHelper._internal();
  static final DBHelper instance = DBHelper._internal();

  Database? _db;

  /// Call once at app startup, before any database access.
  static void initPlatform() {
    if (!kIsWeb && (Platform.isWindows || Platform.isLinux || Platform.isMacOS)) {
      sqfliteFfiInit();
      databaseFactory = databaseFactoryFfi;
    }
  }

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _initDB();
    return _db!;
  }

  Future<Database> _initDB() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'chama_manager.db');

    return openDatabase(
      path,
      version: 2,
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          await db.execute('ALTER TABLE contributions ADD COLUMN for_month TEXT');
        }
      },
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE members(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT,
            join_date TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE contributions(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            member_id INTEGER NOT NULL,
            amount REAL NOT NULL,
            date TEXT NOT NULL,
            note TEXT,
            for_month TEXT,
            FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE
          )
        ''');
        await db.execute('''
          CREATE TABLE loans(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            member_id INTEGER NOT NULL,
            principal REAL NOT NULL,
            interest_rate REAL NOT NULL,
            penalty_rate REAL NOT NULL,
            borrow_date TEXT NOT NULL,
            expected_return_date TEXT NOT NULL,
            actual_return_date TEXT,
            status TEXT NOT NULL,
            FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE
          )
        ''');
      },
    );
  }

  // ---------- MEMBERS ----------

  Future<int> insertMember(Member m) async {
    final db = await database;
    return db.insert('members', m.toMap()..remove('id'));
  }

  Future<int> updateMember(Member m) async {
    final db = await database;
    return db.update('members', m.toMap(), where: 'id = ?', whereArgs: [m.id]);
  }

  Future<int> deleteMember(int id) async {
    final db = await database;
    await db.delete('contributions', where: 'member_id = ?', whereArgs: [id]);
    await db.delete('loans', where: 'member_id = ?', whereArgs: [id]);
    return db.delete('members', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Member>> getMembers() async {
    final db = await database;
    final rows = await db.query('members', orderBy: 'name ASC');
    return rows.map((r) => Member.fromMap(r)).toList();
  }

  Future<Member?> getMember(int id) async {
    final db = await database;
    final rows = await db.query('members', where: 'id = ?', whereArgs: [id]);
    if (rows.isEmpty) return null;
    return Member.fromMap(rows.first);
  }

  // ---------- CONTRIBUTIONS ----------

  Future<int> insertContribution(Contribution c) async {
    final db = await database;
    return db.insert('contributions', c.toMap()..remove('id'));
  }

  Future<int> deleteContribution(int id) async {
    final db = await database;
    return db.delete('contributions', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Contribution>> getContributionsForMember(int memberId) async {
    final db = await database;
    final rows = await db.query(
      'contributions',
      where: 'member_id = ?',
      whereArgs: [memberId],
      orderBy: 'date DESC',
    );
    return rows.map((r) => Contribution.fromMap(r)).toList();
  }

  Future<List<Contribution>> getAllContributions() async {
    final db = await database;
    final rows = await db.query('contributions');
    return rows.map((r) => Contribution.fromMap(r)).toList();
  }

  Future<double> totalContributionsForMember(int memberId) async {
    final db = await database;
    final result = await db.rawQuery(
      'SELECT SUM(amount) as total FROM contributions WHERE member_id = ?',
      [memberId],
    );
    final total = result.first['total'];
    return total == null ? 0.0 : (total as num).toDouble();
  }

  // ---------- LOANS ----------

  Future<int> insertLoan(Loan l) async {
    final db = await database;
    return db.insert('loans', l.toMap()..remove('id'));
  }

  Future<int> updateLoan(Loan l) async {
    final db = await database;
    return db.update('loans', l.toMap(), where: 'id = ?', whereArgs: [l.id]);
  }

  Future<int> deleteLoan(int id) async {
    final db = await database;
    return db.delete('loans', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Loan>> getLoansForMember(int memberId) async {
    final db = await database;
    final rows = await db.query(
      'loans',
      where: 'member_id = ?',
      whereArgs: [memberId],
      orderBy: 'borrow_date DESC',
    );
    return rows.map((r) => Loan.fromMap(r)).toList();
  }

  Future<List<Loan>> getAllActiveLoans() async {
    final db = await database;
    final rows = await db.query('loans', where: "status = 'active'");
    return rows.map((r) => Loan.fromMap(r)).toList();
  }
}
